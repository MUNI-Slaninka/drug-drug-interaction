import pandas as pd
import numpy as np

# Load data from TSV file
data = pd.read_csv("raw.tsv", sep="\t")

with open('interactions.txt', 'r') as file:
    file_content = file.read()

# Step 2: Parse the content to obtain the list of lists
list_of_lists = eval(file_content)

# Step 3: Replace the interactions column in your DataFrame with the obtained list of lists
data['INTERACTIONS'] = list_of_lists
data['ENZYME'] = data['ENZYME'].apply(lambda x: np.array(x.split('|')[:-1]))
data['PATH'] = data['PATH'].apply(lambda x: np.array(x.split('|')[:-1]))
data['TARGET'] = data['TARGET'].apply(lambda x: np.array(x.split('|')[:-1]))

data['STRUCTURE'] = data['STRUCTURE'].apply(lambda x: eval(x))

# Load drug mappings from a TSV file
drug_mappings = pd.read_csv("drug-mappings.tsv", sep='\t')

# Filter out rows with NaN values in 'drugbankId' and 'name' columns
drug_mappings = drug_mappings.dropna(subset=['drugbankId', 'name'])

# Create a dictionary to map DrugBank IDs to drug names
drug_name_mapping = dict(zip(drug_mappings['drugbankId'], drug_mappings['name']))

# Filter out rows with NaN values in 'drugbankId' and 'stitch_id' columns
drug_mappings = drug_mappings.dropna(subset=['drugbankId', 'stitch_id'])

# Create a dictionary to map DrugBank IDs to drug CIDs
drug_cid_mapping = dict(zip(drug_mappings['drugbankId'], drug_mappings['stitch_id']))

# Read drug CID data from a text file
with open('drug_list.txt', 'r') as file:
    for line in file:
        drug_cid, drug_id = line.strip().split()
        # Check if the CID has the correct format
        if not drug_cid.startswith('CID'):
            drug_cid = 'CID1' + drug_cid.zfill(8)
        drug_cid_mapping[drug_id] = drug_cid

# Read additional CID data from a text file
additional_cid_data = {}
with open('drug_names.tsv', 'r') as file:
    for line in file:
        cid, name = line.strip().split("\t")
        additional_cid_data[
            name.lower().strip()] = cid  # Convert name to lowercase and remove leading/trailing whitespaces

    # Fill missing CIDs by matching drug names without capitalization
for drug_id, drug_name in drug_name_mapping.items():
    if pd.isna(drug_cid_mapping.get(drug_id)):
        lowercase_name = drug_name.lower()  # Convert drug name to lowercase
        cid = additional_cid_data.get(lowercase_name)
        if cid:
            drug_cid_mapping[drug_id] = cid

# Map the drug CID information to the corresponding drug ID in your DataFrame
data['DRUG_CID'] = data['DRUG_ID'].map(drug_cid_mapping)
data['DRUG_NAME'] = data['DRUG_ID'].map(drug_name_mapping).str.lower()

# Create an empty dictionary to store side effects for each drug CID
side_effect_dict = {}
cid_stereo_dict = {}
# Iterate over each line in the file
with open('meddra_all_se.tsv', 'r') as file:
    for line in file:
        # Split the line into columns
        columns = line.strip().split('\t')
        if columns[0] not in side_effect_dict:
            # If not, create a new entry with an empty list
            side_effect_dict[columns[0]] = []
        if columns[1] not in side_effect_dict:
            side_effect_dict[columns[1]] = []
        if columns[1] not in cid_stereo_dict:
            cid_stereo_dict[columns[1]] = columns[0]
        # Append the side effect ID to the list corresponding to the drug CID
        side_effect_dict[columns[0]].append(columns[2])
        side_effect_dict[columns[1]].append(columns[2])

# Convert the dictionary values to numpy arrays
for cid, side_effects in side_effect_dict.items():
    side_effect_dict[cid] = np.unique(side_effects)

def conditional_cid_mapping(cid):
    if isinstance(cid, str) and cid.startswith('CID0'):
        return cid_stereo_dict.get(cid)
    else:
        return cid

# Map drug CIDs based on the defined function
data['SIDE_EFFECTS'] = data['DRUG_CID'].map(side_effect_dict)
data['DRUG_CID'] = data['DRUG_CID'].map(conditional_cid_mapping)

indications_dict = {}
with open('meddra_all_indications.tsv', 'r') as file:
    for line in file:
        # Split the line into columns
        columns = line.strip().split('\t')
        # Extract the CID from the first or second column
        # Check if the CID matches any drug CID in the mapping
        if columns[0] not in indications_dict:
            # If not, create a new entry with an empty list
            indications_dict[columns[0]] = []
        # Append the side effect ID to the list corresponding to the drug CID
        indications_dict[columns[0]].append(columns[1])

# Convert the dictionary values to numpy arrays
for cid, indications in indications_dict.items():
    indications_dict[cid] = np.unique(indications)

data['INDICATIONS'] = data['DRUG_CID'].map(indications_dict)

condition_data = pd.read_csv("OFFSIDES.csv")
condition_data['drug_concept_name'] = condition_data['drug_concept_name'].str.lower()
# Group conditions by drug name and aggregate into a NumPy array
drug_conditions = condition_data.groupby('drug_concept_name')['condition_meddra_id'].apply(np.array)

# Convert the resulting Series to a dictionary
drug_conditions_dict = drug_conditions.to_dict()

# Map the dictionary to the 'DRUG_NAME' column in your DataFrame
data['OFFSIDE_EFFECT'] = data['DRUG_NAME'].map(drug_conditions_dict)
data.insert(data.columns.get_loc('DRUG_ID') + 1, 'DRUG_NAME', data.pop('DRUG_NAME'))
data.insert(data.columns.get_loc('DRUG_ID') + 1, 'DRUG_CID', data.pop('DRUG_CID'))

num_rows_without_nan = len(data.dropna())

print("Number of rows without NaN values:", num_rows_without_nan)

num_rows_with_nan = data.isna().any(axis=1).sum()

print("Number of rows with NaN values:", num_rows_with_nan)

print(data.head().to_string())
print(data.dtypes)
data.to_json("processed.json")
# Load the saved data into a DataFrame
df = pd.read_json("../processed.json")
# Display the first few rows of the DataFrame
print(df.head().to_string())
print(df.dtypes)

